package com.bones;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.ResourceBundle;

/**
 * @author : bones
 * @version : 1.0
 */
public class MainController implements Initializable {
    private Integer year;
    private Integer month;
    private Boolean flag = false;
    private String cal;

    @FXML
    private TextField yearStr;
    @FXML
    private TextField monthStr;
    @FXML
    private Text actiontarget1;
    @FXML
    private Text actiontarget2;
    @FXML
    private Text result;
    @FXML
    private Text date;

    /**
     * 点击按钮触发对时间，查询这个月一共有几天，并把这个月对月历打印出来
     * @param event
     */
    @FXML
    public void handlerBtnClick(ActionEvent event) {

        Year_Month_Query query = new Year_Month_Query();
        query.setMonth(month);
        query.setYear(year);
        Integer maxDate = query.getMaxDate();
        if (flag){
            cal = "";
            result.setText("感谢查询！在"+query.getYear()+"年"+query.getMonth()+"月中，共有"+
                    maxDate+"天");
            cal += "日\t一\t二\t三\t四\t五\t六\t\n";
            //获取这个一号是本周的第几天：
            int num = query.calendar.get(Calendar.DAY_OF_WEEK);
            //前面空出来的天数为：
            int day = num - 1;
            int count = 0;
            //在日期前将空格打印出来：
            for (int i = 1; i <= day; i++) {
                cal += "\t";
            }
            //空出来的日子也要放入计数器：
            count = count + day;
            //遍历：从1号开始到maxDay号进行遍历：
            for (int i = 1; i <= maxDate ; i++) {
                cal += i+"\t";
                count++;//每在控制台输出一个数字，计数器做加1操作
                if(count%7 == 0){//当计数器的个数是7的倍数的时候，就换行操作
                    cal += "\n";
                }
                date.setText(cal);
            }
        }else {
            result.setText("请确保输入无误，再查询！！");
        }



    }

    /**
     * 异步校验，利用匿名内部类进行格式（必须是数字）和范围（年份1600-2200，月份1-12）的校验
     * @param location
     * @param resources
     */
    @FXML
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        yearStr.setOnMouseMoved( event -> {
            yearStr.requestFocus();
            if (!yearStr.getText().equals("")){
                actiontarget1.setText("");
                flag = false;
                try {
                    year = Integer.parseInt(yearStr.getText());
                    if (year < 1600 || year > 2200){
                        actiontarget1.setText("输入范围有误！请重新输入！");
                    }else {
                        actiontarget1.setText("输入合法！");
                        flag = true;
                    }

                } catch (RuntimeException e) {
                    actiontarget1.setText("输入内容包含非法字符，请重新输入年份");
                }
            }
        });
        monthStr.setOnMouseMoved( event -> {
            monthStr.requestFocus();
            if (!monthStr.getText().equals("")){
                actiontarget2.setText("");
                flag = false;
                try {
                    month = Integer.parseInt(monthStr.getText());
                    //校验范围：
                    if (month < 1 || month > 12){
                        actiontarget2.setText("输入范围有误！请重新输入！");
                    }else {
                        actiontarget2.setText("输入合法！");
                        flag = true;
                    }
                } catch (RuntimeException e) {
                    actiontarget2.setText("输入内容包含非法字符，请重新输入月份");
                }
            }
        });
    }
}

