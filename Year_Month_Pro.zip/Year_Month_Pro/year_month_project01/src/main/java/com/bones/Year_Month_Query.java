package com.bones;

import java.sql.Date;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author : bones
 * @version : 1.0
 */
public class Year_Month_Query {
    private final Scanner sc = new Scanner(System.in);
    final Calendar calendar = Calendar.getInstance();//抽象类，不能直接创建对象
    private int year;
    private int month;


    /**
     * 根据年份月份得出当月的天数
     * @return 返回天数
     */
    public Integer getMaxDate(){
        //设置日期：
        Date date = Date.valueOf(getYear() + "-" + getMonth()+"-1");
        calendar.setTime(date);
        //获取本月的最大天数：
        return calendar.getActualMaximum(Calendar.DATE);
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }



    public void setYear(int year) {
        this.year = year;
    }

    public void setMonth(int month) {
        this.month = month;
    }
}
