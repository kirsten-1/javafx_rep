package com.bones.test;

/**
 * @author : bones
 * @version : 1.0
 */
public class Test {
    public static void main(String[] args) {
        Year_Month_Query checkController = new Year_Month_Query();
        //获取用户输入的年份和月份：
        checkController.getUserYear();
        checkController.getUserMonth();
        //获取该月份最大天数：
        System.out.println("感谢查询！在"+checkController.getYear()+"年"+checkController.getMonth()+"月中，共有"+
                checkController.getMaxDate()+"天");
    }
}
